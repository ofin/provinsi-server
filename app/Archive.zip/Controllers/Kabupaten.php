<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\KabupatenModel;
use CodeIgniter\API\ResponseTrait;

class Kabupaten extends BaseController
{
    use ResponseTrait;
    public function index()
    {
        $kabModel = new KabupatenModel();
        $data = $kabModel->findAll();
        return $this->respond($data);
        //
    }
}
